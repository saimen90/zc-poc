#!/usr/bin/env python
# -*- coding:utf-8 -*-
import requests
import json
import logging
import urllib
import hashlib
import hmac
import time
import sys


reload(sys)
sys.setdefaultencoding("utf-8")

EASYOPS_OPEN_API_HOST = ""
ACCESS_KEY = ""
SECRET_KEY = ""

FORMAT = '[%(asctime)s %(filename)s(line:%(lineno)d) %(levelname)s] %(message)s'
logging.basicConfig(format=FORMAT)
logger = logging.getLogger('log')
logger.setLevel(logging.INFO)

class Api:
    def __init__(self, ip=EASYOPS_OPEN_API_HOST, access_key=ACCESS_KEY, secret_key=SECRET_KEY):
        self.session = requests.session()
        self.ip = ip
        self.access_key = access_key
        self.secret_key = secret_key

    def easy_request(self, uri, ip=None, session=False, method='GET', params=None):
        if not params:
            params = dict()

        # 时间戳
        request_time = int(time.time())

        # headers处理
        headers = dict()
        headers['Host'] = 'openapi.easyops-only.com'
        headers['Content-Type'] = 'application/json'

        # 签名构建
        signature = Api.gen_signature(
            access_key=self.access_key,
            secret_key=self.secret_key,
            request_time=request_time,
            method=method,
            uri=uri,
            data=params,
            content_type=headers.get('Content-Type')
        )

        # 默认的三个参数
        keys = {
            "accesskey": self.access_key,
            "signature": signature,
            "expires": str(request_time)
        }

        # 拼接IP和URI
        if not ip:
            url = "http://%s%s" % (self.ip, uri)
        else:
            url = "http://%s%s" % (ip, uri)

        # 整理URL参数
        if method == 'GET' or method == 'DELETE':
            params.update(keys)
            url_params = urllib.urlencode(params)
        else:
            url_params = urllib.urlencode(keys)

        # 拼接URL和URL参数
        if '?' not in url:
            url = '%s?%s' % (url, url_params)
        else:
            url = '%s&%s' % (url, url_params)
        #print( "request url: {}".format(url))

        # 是否会话访问
        if session:
            response = self.session.request(url=url, method=method, headers=headers, json=params)
        else:
            response = requests.request(url=url, method=method, headers=headers, json=params)
        #print response.text
        # 返回结果
        if response.status_code == 200:
            return json.loads(response.text)

        logger.error("http_request %s return %s" % (response.url, response.status_code))
        raise Exception("http_request %s return %s" % (response.url, response.status_code))

    @staticmethod
    def gen_signature(access_key, secret_key, request_time, method, uri, data=None, content_type='application/json'):
        if method == 'GET' or method == 'DELETE':
            url_params = ''.join(['%s%s' % (key, data[key]) for key in sorted(data.keys())])
        else:
            url_params = ''
        if method == 'POST' or method == 'PUT':
            m = hashlib.md5()
            m.update(json.dumps(data).encode('utf-8'))
            body_content = m.hexdigest()
        else:
            body_content = ''

        str_sign = '\n'.join([
            method,  # 指HTTP请求方法如, GET, POST, PUT, DELETE
            uri,  # 指所访问的资源路径如, /cmdb/object/list
            url_params,  # 指请求中的URL参数, 其构成规则如下: 1. 对参数key进行升序排序 2. 对于所有参数以key+value方式串联
            content_type,  # 请求Header中的Content-Type值
            body_content,  # 请求Header中的Content-MD5值, 等同于对body数据的md5sum
            str(request_time),  # 请求发生时的时间戳
            access_key  # 用户自己的AccessKey
        ])

        # 利用哈希算法，以一个密钥和一个消息为输入，生成一个消息摘要作为输出，即为使用秘钥和消息生成一个签名
        signature = hmac.new(secret_key, str_sign, hashlib.sha1).hexdigest()
        return signature


if __name__ == "__main__":
    api = Api()
    aaaa = 1
    BUSINESS_list = []
    while True:
        BUSINESS_params = {
        "sort": {"name": 1},
        "fields": {"name": True, "_businesses_APP": True, "instanceId": True,"_businesses_APP.memo":True,"developer":True,
                   "_businesses_APP.owner": True,
                   "_businesses_APP.tester": True,
                   "_businesses_APP.developer": True,
                   "_businesses_APP.USER_WB": True,
                   "_businesses_APP.PIPELINE_PROJECT":True,"_businesses_APP.PIPELINE_PROJECT._PIPELINE":True
                   },
        "page_size": 3000,
        "page": aaaa
        }
        # 查询所有主机
        BUSINESS_ret_info = api.easy_request("/cmdb/object/BUSINESS/instance/_search", method="POST", params=BUSINESS_params)
        if len(BUSINESS_ret_info["data"]["list"]) > 0:
            BUSINESS_list.extend(BUSINESS_ret_info["data"]["list"])
            aaaa += 1
        else:
            break
    print "系统\t系统id\t系统开发负责人\t应用\t应用id\t应用的所有负责人\t应用备注\t项目\t项目id"
    for BUSINESS_info in BUSINESS_list:
        if BUSINESS_info["_businesses_APP"]:
            for app_info in BUSINESS_info["_businesses_APP"]:
                owner_user = [] #负责人
                owner_user.extend(app_info["owner"])     #运维负责人
                owner_user.extend(app_info["tester"])    #测试负责人
                owner_user.extend(app_info["developer"]) #开发负责人
                owner_user.extend(app_info["USER_WB"])   #外包开发人员
                if app_info["PIPELINE_PROJECT"]:
                    for aaaa in app_info["PIPELINE_PROJECT"]:
                        #print app_info["PIPELINE_PROJECT"][0]["name"]
                        print BUSINESS_info["name"], "\t", BUSINESS_info["instanceId"], "\t", ",".join(
                            ["%s(%s)" % (a["name"], a["nickname"]) for a in BUSINESS_info["developer"]]), "\t",app_info[
                            "name"], "\t", app_info["instanceId"], "\t", ",".join(
                            ["%s(%s)" % (a["name"], a["nickname"]) for a in owner_user]), "\t", app_info[
                            "memo"] if "memo" in app_info else "","\t",aaaa["name"],"\t",aaaa["instanceId"]
                else:

                    print BUSINESS_info["name"], "\t", BUSINESS_info["instanceId"], "\t", ",".join(
                        ["%s(%s)" % (a["name"], a["nickname"]) for a in BUSINESS_info["developer"]]), "\t", app_info[
                        "name"], "\t", app_info["instanceId"], "\t", ",".join(
                        ["%s(%s)" % (a["name"], a["nickname"]) for a in owner_user]), "\t", app_info[
                        "memo"] if "memo" in app_info else ""

        print BUSINESS_info["name"], "\t", BUSINESS_info["instanceId"],"\t",",".join(["%s(%s)" % (a["name"],a["nickname"]) for a in BUSINESS_info["developer"]])