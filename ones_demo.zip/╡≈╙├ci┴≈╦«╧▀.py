#!/usr/bin/env python
# -*- coding:utf-8 -*-
import requests
import json
import logging
import urllib
import hashlib
import hmac
import time
import sys


reload(sys)
sys.setdefaultencoding("utf-8")


EASYOPS_OPEN_API_HOST = ""
#pro
ACCESS_KEY = ""
SECRET_KEY = ""

FORMAT = '[%(asctime)s %(filename)s(line:%(lineno)d) %(levelname)s] %(message)s'
logging.basicConfig(format=FORMAT)
logger = logging.getLogger('log')
logger.setLevel(logging.INFO)


class Api:
    def __init__(self, ip=EASYOPS_OPEN_API_HOST, access_key=ACCESS_KEY, secret_key=SECRET_KEY):
        self.session = requests.session()
        self.ip = ip
        self.access_key = access_key
        self.secret_key = secret_key

    def easy_request(self, uri, ip=None, session=False, method='GET', params=None,files=None):
        #print "="*80
        if not params:
            params = dict()

        # 时间戳
        request_time = int(time.time())

        # headers处理
        headers = dict()
        headers['Host'] = 'openapi.easyops-only.com'
        headers['Content-Type'] = 'application/json'

        # 签名构建
        signature = Api.gen_signature(
            access_key=self.access_key,
            secret_key=self.secret_key,
            request_time=request_time,
            method=method,
            uri=uri,
            data=params,
            content_type=headers.get('Content-Type')
        )

        # 默认的三个参数
        keys = {
            "accesskey": self.access_key,
            "signature": signature,
            "expires": str(request_time)
        }

        # 拼接IP和URI
        if not ip:
            url = "http://%s%s" % (self.ip, uri)
        else:
            url = "http://%s%s" % (ip, uri)

        # 整理URL参数
        if method == 'GET' or method == 'DELETE':
            params.update(keys)
            url_params = urllib.urlencode(params)
        else:
            url_params = urllib.urlencode(keys)

        # 拼接URL和URL参数
        if '?' not in url:
            url = '%s?%s' % (url, url_params)
        else:
            url = '%s&%s' % (url, url_params)
        #print( "request url: {}".format(url))

        # 是否会话访问
        if session:
            response = self.session.request(url=url,files=files, method=method, headers=headers, json=params)
        else:
            response = requests.request(url=url,files=files, method=method, headers=headers, json=params)
        #print response.text

        # 返回结果
        if response.status_code == 200:
            return json.loads(response.text)
        elif response.status_code == 500:
            return json.loads(response.text)

        logger.error("http_request %s return %s" % (response.url, response.status_code))
        raise Exception("http_request %s return %s" % (response.url, response.status_code))

    @staticmethod
    def gen_signature(access_key, secret_key, request_time, method, uri, data=None, content_type='application/json'):
        if method == 'GET' or method == 'DELETE':
            url_params = ''.join(['%s%s' % (key, data[key]) for key in sorted(data.keys())])
        else:
            url_params = ''
        if method == 'POST' or method == 'PUT':
            m = hashlib.md5()
            m.update(json.dumps(data).encode('utf-8'))
            body_content = m.hexdigest()
        else:
            body_content = ''

        str_sign = '\n'.join([
            method,  # 指HTTP请求方法如, GET, POST, PUT, DELETE
            uri,  # 指所访问的资源路径如, /cmdb/object/list
            url_params,  # 指请求中的URL参数, 其构成规则如下: 1. 对参数key进行升序排序 2. 对于所有参数以key+value方式串联
            content_type,  # 请求Header中的Content-Type值
            body_content,  # 请求Header中的Content-MD5值, 等同于对body数据的md5sum
            str(request_time),  # 请求发生时的时间戳
            access_key  # 用户自己的AccessKey
        ])

        # 利用哈希算法，以一个密钥和一个消息为输入，生成一个消息摘要作为输出，即为使用秘钥和消息生成一个签名
        signature = hmac.new(secret_key, str_sign, hashlib.sha1).hexdigest()
        return signature



# 查看流水线构建日志(log_id)
def search_log(status_rets):
    #根据构建信息，获取构建步骤以及构建id
    for log_info in status_rets["data"]["stages"]:
        print "步骤名称 : %s" % (log_info["stage_name"])
        #获取构建id
        for loginfo in log_info["steps"]:
            #根据id打印构建日志
            url3 = "/pipeline/api/pipeline/v1/progress_log/%s" % (loginfo["log_id"])
            progress_log_ret = api.easy_request(url3, method="GET", params={})
            print progress_log_ret["data"]["logs"]

#执行流水线
def execute_pipelines(project_id,pipeline_id,body):
    #project_id:项目id
    #pipeline_id 流水线id
    #body：流水线执行时的输入（变量）
    url = "/pipeline/api/pipeline/v1/projects/%s/pipelines/%s/execute" % (project_id, pipeline_id)
    pi_res = api.easy_request(url, method="POST", params=body)
    print pi_res
    execute_id = pi_res["data"]["id"]
    print execute_id

    while True:
        time.sleep(2)
        #循环获取流水线执行信息
        url2 = "/pipeline/api/pipeline/v1/builds/%s" % (execute_id)
        status_ret = api.easy_request(url2, method="GET", params={})
        #根据执行信息打印状态和日志
        if status_ret["data"]["status"]["state"] == "succeeded":
            print "流水线执行完成"
            search_log(status_ret)
            break
        elif status_ret["data"]["status"]["state"] == "failed":
            print "流水线执行失败"
            search_log(status_ret)
            exit(1)
        else:
            print "执行中"

#查询应用所拥有的流水线
def search_app_project(app_name):
    APP_params = {
        "sort": {"name": 1},
        "fields": {"*": True,"PIPELINE_PROJECT":True,"PIPELINE_PROJECT._PIPELINE":True},
        "query": {"name": {"$in": [app_name]}},
        "page_size": 3000,
        "page": 1
    }
    # 查询应用信息
    APP_ret_info = api.easy_request("/cmdb/object/APP/instance/_search", method="POST", params=APP_params)
    for app_info in APP_ret_info["data"]["list"]:
        #应用所拥有的流水线_代码项目
        for pipe_proj_info in  app_info["PIPELINE_PROJECT"]:
            print pipe_proj_info["name"],pipe_proj_info["instanceId"]    #流水线_代码项目名称和id
            #流水线
            for pipe_info in  pipe_proj_info["_PIPELINE"]:
                print pipe_info["instanceId"],pipe_info["name"],pipe_info["alias_name"]  #流水线id,名称,流水线可读名称
                input_body = {}    #初始化执行流水线所需要输入的变量
                if "variables" in pipe_info:      #流水线变量有可能为空
                    input_list = []
                    for pip_1 in  pipe_info["variables"]:  #流水线变量
                        if "value" in pip_1:    #判断是否有value，没有则将value为空（如：{u'name': u'appowner', 'value': None}）
                            input_list.append(pip_1)
                        else:
                            pip_1["value"] = None
                            input_list.append(pip_1)
                    input_body["inputs"] = input_list
                if build_type == "branch":
                    input_body["branch"] = "branch_net_scope"   #分支名称
                elif build_type == "tag":
                    input_body["tag"] = "release_1.1"   #tag名称
                else:
                    print "部署方式错误"
                    exit(1)
                print input_body  #打印执行时所需要的参数


#查询流水线分支列表(project_id  :项目id)
def search_branch_list(project_id):
    branches_list = []
    url = "/pipeline/api/pipeline/v1/projects/%s/branches" % (project_id)
    pi_res = api.easy_request(url, method="GET", params={"page_size":200})
    for a in  pi_res["data"]["list"]:
        branches_list.append(a["name"])
    print "分支列表 : %s " % (",".join(branches_list))
    return branches_list

#################################################
app_name = "投资支持辅助系统网关服务"   #应用名称（用于此次测试）
build_type = "branch"  #部署方式，branch或者tag

if __name__ == "__main__":
    api = Api()
    search_app_project(app_name)

    project_id = "5a3f2e1cdb2ff"  #:项目id
    pipeline_id = "5a40382f43d16"

    body = {"inputs":
                [{"name":"upzip","value":"false"},
                 {"name":"pom_file","value":"pom.xml"},
                 {"name":"output_artifact","value":"target/IA.jar"},
                 {"name":"package_id","value":"eb0b2d547c3869324085801eb7764d3d"},
                 {"name":"approvers","value":"liulu,wangy2,lifang,exchenl"},
                 {"name":"appowner","value":None}
                 ],
            "branch":"branch_net_scope"
            #,"tag":"aaaaaaaa"
            } #执行时的请求参数
    #执行流水线
    #execute_pipelines(project_id,pipeline_id,body)
    print "========="
    # 查询流水线分支列表(project_id  :项目id)
    search_branch_list(project_id)


